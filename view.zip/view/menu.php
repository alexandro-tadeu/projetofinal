<hr>
<div class="form-group">
    <div class="mx-auto" style="width: 1200px;">
        <a href="cadastro.php" class="btn btn-success">Cadastar</a>
        <a href="index.php" class="btn btn-default">Consultar</a>
    </div>
</div>
<hr>